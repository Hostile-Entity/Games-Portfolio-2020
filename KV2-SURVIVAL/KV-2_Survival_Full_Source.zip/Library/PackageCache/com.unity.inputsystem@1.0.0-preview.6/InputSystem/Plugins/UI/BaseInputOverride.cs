using UnityEngine.EventSystems;

namespace UnityEngine.InputSystem.UI
{
    internal class BaseInputOverride : BaseInput
    {
        public override string compositionString { get; }
    }
}
